---
name: koncepto-apollo-prospecting
description: Planeja e opera prospecção B2B no Apollo via MCP. Use para definir estratégia e Deal Flow, segmentar decisores, desenhar ou revisar cadências, criar tarefas aprovadas, acompanhar respostas e gerar um painel HTML com dados reais do Apollo. Abrange prospecção, mudança de contato, retomada agendada e retomada sem conexão após 90 dias.
---

# Koncepto Apollo Prospecting

Use o Apollo como sistema oficial de registro e execução. Use o Claude para raciocínio, qualificação, redação, análise e orquestração via MCP. Nunca mantenha uma segunda base operacional no painel.

## Primeiro uso

1. Confirme que o conector remoto oficial do Apollo está ativo e autenticado.
2. Inventarie as ferramentas MCP disponíveis; nomes e permissões podem variar. Não presuma que uma ação de escrita existe.
3. Leia `references/strategic-module.md` e `references/operational-module.md`.
4. Colete apenas lacunas essenciais: empresa/oferta, mercado, meta/período, ICP, personas, restrições, remetentes, fusos e capacidade diária.
5. Consulte o Apollo em modo leitura e diferencie claramente dado observado, inferência e dado ausente.
6. Apresente a estratégia, o Deal Flow, os segmentos, as quatro cadências e o plano de implantação antes de qualquer escrita.

Se o MCP não estiver disponível, trabalhe em modo projeto: gere os artefatos para revisão e uma lista exata de ações manuais no Apollo. Não invente dados.

## Regras de segurança operacional

- Nunca inscreva contatos, ative sequência, envie e-mail, faça conexão LinkedIn, altere registro ou crie tarefa sem mostrar uma prévia e receber aprovação explícita para o lote e a ação.
- Trate respostas, opt-out, reunião marcada, bounce e contato inválido como sinais de parada. Não continue automaticamente.
- LinkedIn é manual na V1. Gere tarefa e sugestão de texto; não automatize conexão ou mensagem.
- Uma referência só pode ser mencionada se estiver registrada em campo ou nota do contato.
- Não exponha segredos, tokens, dados sensíveis ou listas completas no painel.
- Respeite limites da conta, políticas do Apollo, regras do canal, consentimento e legislação aplicável.
- Para operações em massa, comece com amostra de até 10 contatos, valide e amplie somente após aprovação.

## Fluxo padrão

### 1. Diagnosticar

Leia dados de contas, contatos, listas, sequências, tarefas, respostas e métricas disponíveis. Registre a cobertura e limitações da consulta. Classifique conta e pessoa separadamente e identifique o comitê de compra.

### 2. Construir o módulo estratégico

Siga `references/strategic-module.md`. Entregue objetivo e hipótese; TAM/SAM/SOM; ICP, personas, exclusões e sinais; Deal Flow planejado, necessário e realizado; lacunas SPICED; segmentos priorizados.

### 3. Construir o módulo operacional

Siga `references/operational-module.md` e `references/sequences.md`. Para cada sequência, defina entrada, saída, passos, responsáveis, SLA, campos obrigatórios e regras de parada. Use `references/writing-and-calls.md` para copy e roteiro.

### 4. Aprovar e implantar

Mostre uma tabela de alterações propostas com objeto, quantidade, ação e efeito. Após aprovação explícita, execute somente o escopo aprovado pelas ferramentas disponíveis. Leia novamente uma amostra para verificar o resultado. Se a escrita não for suportada, produza checklist de implantação manual.

### 5. Operar diariamente

Priorize respostas e compromissos agendados, depois tarefas vencidas e novas entradas dentro do limite. Ao receber resposta, pause a automação daquele contato e entregue ao humano: resumo, evidências, intenção provável, riscos e resposta sugerida.

### 6. Gerar painel

Monte um JSON conforme `references/data-contracts.md` e execute `python3 scripts/render_dashboard.py snapshot.json dashboard.html`.

O painel é uma fotografia gerada sob demanda. Exiba data/hora, período, cobertura e origem. Se uma métrica não estiver disponível, use `null`; nunca estime silenciosamente.

## Notificações

Use tarefas do Apollo com responsável, vencimento, prioridade e contexto como mecanismo operacional. As notificações dependem das configurações nativas da conta Apollo; confirme isso com o usuário e não alegue que uma notificação foi configurada sem evidência. Para alertas fora do Apollo, gere uma especificação separada — não crie integração externa por conta própria.

## Formato de saída

Encerre com: situação observada e cobertura; decisões e parâmetros aprovados; fila por responsável e vencimento; alterações no Apollo executadas/não executadas e verificação; alertas; próxima decisão humana.
